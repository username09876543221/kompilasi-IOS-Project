//
//  Question.swift
//  Quizzler-iOS13
//
//  Created by Ahmad Ilmifi Arkan on 18/11/20.
//  Copyright © 2020 The App Brewery. All rights reserved.
//

import Foundation

struct Question {
    let text : String
    let answer : String
}
