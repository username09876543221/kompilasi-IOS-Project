//
//  Weather.swift
//  Clima
//
//  Created by Ahmad Ilmifi Arkan on 23/11/20.
//  Copyright © 2020 App Brewery. All rights reserved.
//

import Foundation

struct WeatherManager {
    let weatherURL = "http://api.openweathermap.org/data/2.5/weather?appid=601269c047d2b92dfd9e9aad33d2e8c7"


func fetchWeather(cityName : String) {
    let urlString = "\(weatherURL)&q=\(cityName)"
    print(urlString)
}
    
    func performRequest(urlString) -> String {
        if let url = URL(String: urlString) {
            let session = URLSession(configuration: .default)
            
            let task = session.dataTask(with: url) {(data, respone, error)in
                if error != nil{
                    print(error!)
                return
            }
        }
            task.resume()
    }
    
}

    func parseJSON(weatherData: String) {
        let decoder = JSONDecoder()
        do{
            let decodedData = try.
        }
    }
